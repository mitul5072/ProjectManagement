﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PM.Core.Model;
using ProjectManagement.Web.Helper;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement.Web.Controllers
{
    public class ProjectsController : Controller
    {
        readonly ProjectApi _projectAPI = new ProjectApi();

        // GET: Projects
        public async Task<IActionResult> Index()
        {
            List<ProjectModel> dto = new List<ProjectModel>();

            HttpClient client = _projectAPI.InitializeClient();

            HttpResponseMessage res = await client.GetAsync("api/Projects");

            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;

                dto = JsonConvert.DeserializeObject<List<ProjectModel>>(result);

            }
            return View(dto);
        }

        // GET: Projects/Create  
        public IActionResult Create()
        {
            return View();
        }

        // POST: Projects/Create  
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("ProjectId,ProjectName,Description,StartDate,EndDate,ProjectStatus")] ProjectModel project)
        {
            if (ModelState.IsValid)
            {
                HttpClient client = _projectAPI.InitializeClient();

                var content = new StringContent(JsonConvert.SerializeObject(project), Encoding.UTF8, "application/json");
                HttpResponseMessage res = client.PostAsync("api/Projects", content).Result;
                if (res.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }
            return View(project);
        }

        // GET: Projects/Edit/1  
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            List<ProjectModel> dto = new List<ProjectModel>();
            HttpClient client = _projectAPI.InitializeClient();
            HttpResponseMessage res = await client.GetAsync("api/Projects");

            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                dto = JsonConvert.DeserializeObject<List<ProjectModel>>(result);
            }

            var project = dto.SingleOrDefault(m => m.ProjectId == id);
            if (project == null)
            {
                return NotFound();
            }

            return View(project);
        }

        // POST: Projects/Edit/1  
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(long id, [Bind("ProjectId,ProjectName,Description,StartDate,EndDate,ProjectStatus")] ProjectModel project)
        {
            if (id != project.ProjectId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                HttpClient client = _projectAPI.InitializeClient();

                var content = new StringContent(JsonConvert.SerializeObject(project), Encoding.UTF8, "application/json");
                HttpResponseMessage res = client.PutAsync("api/Projects", content).Result;
                if (res.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }
            return View(project);
        }

        // GET: Projects/Delete/1  
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            List<ProjectModel> dto = new List<ProjectModel>();
            HttpClient client = _projectAPI.InitializeClient();
            HttpResponseMessage res = await client.GetAsync("api/Projects");

            if (res.IsSuccessStatusCode)
            {
                var result = res.Content.ReadAsStringAsync().Result;
                dto = JsonConvert.DeserializeObject<List<ProjectModel>>(result);
            }

            var project = dto.SingleOrDefault(m => m.ProjectId == id);
            if (project == null)
            {
                return NotFound();
            }

            return View(project);
        }

        // POST: Projects/Delete/5  
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(long id)
        {
            HttpClient client = _projectAPI.InitializeClient();
            HttpResponseMessage res = client.DeleteAsync($"api/Projects/{id}").Result;
            if (res.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return NotFound();
        }

    }
}