﻿using System;

namespace PM.Core.Model
{
    public class ProjectModel
    {
        public long ProjectId { get; set; }
        public string ProjectName { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string ProjectStatus { get; set; }
    }
}
